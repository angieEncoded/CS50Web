# Javascript

- Accessing items on the page
  -  Get the first h1 element
     - ```document.querySelector("h1").innerHTML = "Goodbye"```
     - 