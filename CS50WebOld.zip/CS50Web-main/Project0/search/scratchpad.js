https://
www.google.com /
    search ?
    as_q = tricolor + rat + terrier
    & as_qdr=all
        & as_occt=any
            & safe=images
                & as_oq=
& as_nlo=
& as_nhi=
& lr=
& cr=
& as_sitesearch=
& as_filetype=
& tbs=
& as_epq=% 22this + is + a + test % 22
    & as_q=
& as_oq=
& as_eq=
& as_nlo=
& as_nhi=
& as_qdr=all
    & lr=
& cr=
& as_sitesearch=
& as_occt=any
    & safe=images
        & as_filetype=
& tbs=
& as_oq=miniature + OR + standard & as_qdr=all
    & as_occt=any
        & safe=images
            & as_eq=
& as_nlo=
& as_nhi=
& lr=
& cr=
& as_sitesearch=
& as_filetype=
& tbs=
& as_eq=-rodent % 2C + -% 22Jack + Russell % 22
    & as_qdr=all
        & as_occt=any
            & safe=images
                & as_nlo=
& as_nhi=
& lr=
& cr=
& as_sitesearch=
& as_filetype=
& tbs=



https://www.google.com/search?
as_q = tricolor + rat + terrier
    & as_epq=% 22this + is + a + test % 22
        & as_oq=miniature + OR + standard
            & as_eq=-rodent % 2C + -% 22Jack + Russell % 22






