document.addEventListener("DOMContentLoaded", () => {

    const getPets = async () => {
        try {
            // Get results
            const results = await fetch('http://10.10.50.92/msipets?acmd=getSearchList&pet_type=ALL')
            // convert it to json
            const jsonResults = await results.json()

            return jsonResults

        } catch (error) {
            console.log(error)
        }

    }


    document.querySelector('form').onsubmit = () => {

        getPets()
            .then((results) => {
                const petName = document.querySelector('#pet').value.toUpperCase();
                for (let item of results.data) {
                    if (petName === item.petname) {
                        console.log(item)
                        document.querySelector('.result').innerHTML = item.petid
                    }
                }


            })



        return false;

    }


})