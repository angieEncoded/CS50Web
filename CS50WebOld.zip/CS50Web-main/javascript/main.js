function hello() {
    let textNode = document.querySelector('h1')
    if (textNode.innerHTML === "Hello!") {
        textNode.innerHTML = "Goodbye!"
    } else {
        textNode.innerHTML = "Hello!"
    }
}

function count() {
    let counter = localStorage.getItem('counter')
    counter++;
    document.querySelector('.counter').innerHTML = counter;

    // save back to local storage
    localStorage.setItem('counter', counter)

    if (counter % 10 === 0) {
        alert(`Count is now ${counter}`)
    }
}





// Register an event listener to tell us when the page is loaded
document.addEventListener("DOMContentLoaded", function () {

    // check if there is something in the local storage
    if (!localStorage.getItem('counter')) {
        // if not, set it to 0
        localStorage.setItem('counter', 0)
    }

    // update the h1 to the count
    document.querySelector('.counter').innerHTML = localStorage.getItem('counter')


    // Register a reference to this function
    document.querySelector('.countButton').onclick = count;

    // Alternative syntax
    // document.querySelector('.countButton').addEventListener('click', count)

    // Get at an element
    document.querySelector('form').onsubmit = (event) => {
        event.preventDefault();
        // Get data from the form
        const name = document.querySelector('#name').value
        content = `Hello, ${name}`
        alert(`Hello, ${name}`)
    };


    // Change some css properties
    // Add an event listener to ll the buttons and then for each, do something
    const buttons = document.querySelectorAll('.colorbuttons').forEach(button => {
        // On an onclick of any of the buttons
        button.onclick = () => {
            // Select the target h1 and change the color to the value stored in the "data-" property
            document.querySelector('#hello').style.color = button.dataset.color;
        }
    })


    // Example with a drop down instead - note that 'this' doesn't work with the arrow function here
    document.querySelector('select').onchange = function () {
        document.querySelector('#hello').style.color = this.value;
    }





    // How to use document.querySelector()
    // document.querySelector('tag')
    // document.querySelector('#id')
    // document.querySelector('.class')

    // Common events
    /*
    onclick
    onmouseover\onmouseout
    onkeydown\onkeyup
    onload
    onblur
    */

})