document.addEventListener("DOMContentLoaded", () => {



    // by default, submit button should be disabled
    document.querySelector('#tasksubmit').disabled = true;

    // listen for keystrokes
    document.querySelector('#task').onkeyup = () => {
        if (document.querySelector('#task').value.length > 0) {
            document.querySelector('#tasksubmit').disabled = false
        } else {
            document.querySelector('#tasksubmit').disabled = true
        }

    }

    document.querySelector('form').onsubmit = (event) => {
        // get what the user typed in
        const task = document.querySelector('#task').value

        console.log(task)
        // Create a new list item and assign the data to it
        const li = document.createElement('li')
        li.innerHTML = task;

        // Get the DOM node and append to it
        document.querySelector('#tasks').append(li)

        // Clean up the form
        document.querySelector('#task').value = ""


        // disable button again

        document.querySelector('#tasksubmit').disabled = true;

        // This is not needed anymore?
        // event.preventDefault()
        // This is how Brian showed us to not submit the form
        return false;
    }





})