# Django reference skeleton
- Reference code for djago apps