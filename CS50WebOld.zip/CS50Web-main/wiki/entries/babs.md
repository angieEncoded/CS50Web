# This is a page about my cat Babs
- She is a tabby
- She is 5 years old